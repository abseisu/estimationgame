import java.util.ArrayList;

public class User extends Player{

    public User(ArrayList<Card> hand, int estimate, String name) {
        super(hand,estimate, name);
    }

}
